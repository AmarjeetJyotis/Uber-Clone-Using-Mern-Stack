# Project Detail.
- Here i'm creating an uber-clone app.
- fun-fact: I don't enjoy using the word master i prefer main, i think the word master has many connotation to  it, because when i think master i think american slavery 'master', then i go to master your destiny.

# Bugs-Report
- finally found the bug that has been giving me problems, 
    - After i have been trying to fix this bug for a day and a half now i have found the problem. 
    - but let me put it on record that chatGPT has officialy dissapointed me. 
    - chatGPT does not provide assistance as good as i would have hoped, like they completely didn't help me in the bugs i found in this build, i used to say the **I**         in (AI) is lound but now (Is not make sure).
    - the bug in my code was not breaking my build but just an alert which was kinda annoying, so after all my debuging energy was depleted i decided to just create            anouther branch from main and build again, mind you i'm half-way done with my build and due to my programming experience i had created a branch and the problem          started in that branch.
    - so i ceated the new branch and when i was working on it i got a few errors( those guesable ones ), I then tried to solve them **but this time i decided to learn          how to read expo error messages and see how do they point to where the error is**, which helped because after fixing those 2-errors i was able to read the error          message and know where it is pointing me to.
    - after learning to read these errors that's when i came back here to put my knowledge to the test and i was able with one go, to pin point where the error was and              resolve it.👏
- fun times i tell you.
- i like how there is no auto-correct here and by default my spelling is right.

- chatGPT just saved me. I deduce that chatGPT is more usefull when the outcome is already know, but i also knew the outcome yesterday i wanted it to find bugs, my       question was where does the code break and chatGPT couldn't answer that.

# hurdles
- due to the phone model i'm using the screen is not displaying full screen and therefore i have been unable to test slide back functionality,I also can't see the Choose button at the bottom. 

### remember these
- safeareaview is for ios // safeareaprovider for andriod.  bottom-100/100
- travelTime errors need optional chaining(?)
